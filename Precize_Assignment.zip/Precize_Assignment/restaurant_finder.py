import json
from serpapi import GoogleSearch
import os

api_key = os.getenv("SERPAPI_API_KEY")


# Function to search top restaurants in a city using SerpAPI
def get_top_restaurants(city, api_key):
    params = {
        "engine": "google",
        "q": f"top 10 restaurants in {city}",
        "location": f"{city}, India",  # Make it more specific
        "hl": "en",
        "gl": "in",  # Target India explicitly
        "google_domain": "google.co.in",  # Use Indian Google domain
        "api_key": api_key
    }

    print("\nSearching using SerpAPI...")

    search = GoogleSearch(params)
    results = search.get_dict()

    # DEBUG: Print the full API response
    print("\nRaw SerpAPI Response:\n")
    print(json.dumps(results, indent=2))

    # Check for errors in the response
    if "error" in results:
        print("SerpAPI Error:", results["error"])
        return {}

    # Check if 'local_results' exists and is a list
    if "local_results" not in results or not isinstance(results["local_results"], list):
        print("'local_results' not found or is not a list.")
        return {}

    # Optional deeper structure debug
    print("Type of local_results:", type(results["local_results"]))
    print("First item sample:", results["local_results"][0] if results["local_results"] else "No results")

    restaurants = {}
    for result in results["local_results"]:
        name = result.get("title")
        rating = result.get("rating")
        reviews = result.get("reviews")
        if name:
            restaurants[name] = {
                "rating": rating,
                "reviews": reviews
            }

    return restaurants


# Main script execution
def main():
    city = input("Enter the name of the city: ").strip()

    # Add your SerpAPI key here
    api_key = os.getenv("SERPAPI_API_KEY") or "YOUR_SERPAPI_KEY"

    if not api_key or api_key == "YOUR_SERPAPI_KEY":
        print("Please set a valid SerpAPI API key.")
        return

    print(f"\nSearching for top 10 restaurants in {city}...\n")
    top_restaurants = get_top_restaurants(city, api_key)

    if not top_restaurants:
        print("No restaurants data retrieved. Please check your API key or try another city.")
    return


    # Save data to JSON
    file_name = f"{city.lower().replace(' ', '_')}_top_restaurants.json"
    with open(file_name, "w") as f:
        json.dump(top_restaurants, f, indent=4)

    print(f" Top restaurants saved to {file_name}")

if __name__ == "__main__":
    main()
